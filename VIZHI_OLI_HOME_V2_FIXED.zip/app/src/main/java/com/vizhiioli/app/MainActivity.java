package com.vizhiioli.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    int gold = Color.rgb(232,181,55);
    int bg = Color.rgb(8,11,17);

    TextView tv(String s, int z) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(z);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    Button card(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(25,29,38));
        g.setStroke(2, gold);
        g.setCornerRadius(28);
        b.setBackground(g);
        return b;
    }

    public void onCreate(Bundle x) {
        super.onCreate(x);

        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(bg);

        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER_HORIZONTAL);
        r.setPadding(20, 18, 20, 30);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.vizhi_oli_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(-1, 210);
        logoParams.setMargins(0, 8, 0, 4);
        r.addView(logo, logoParams);

        TextView tag = tv("ஆடியோ  •  வீடியோ  •  கதைகள்", 18);
        tag.setTextColor(gold);
        r.addView(tag, new LinearLayout.LayoutParams(-1, 55));

        r.addView(tv("விழியொலிக்கு வரவேற்கிறோம்", 22),
                new LinearLayout.LayoutParams(-1, 65));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);

        for (String s : new String[]{"🎧\nஆடியோ", "▶\nவீடியோ", "📖\nகதைகள்"}) {
            Button b = card(s);
            LinearLayout.LayoutParams p =
                    new LinearLayout.LayoutParams(0, 130, 1);
            p.setMargins(6, 6, 6, 6);
            row.addView(b, p);
        }
        r.addView(row);

        TextView sec = tv("பிரபலமானவை", 20);
        sec.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        r.addView(sec, new LinearLayout.LayoutParams(-1, 70));

        r.addView(card("✨  புதிய கதைகள்\n   விரைவில்..."),
                new LinearLayout.LayoutParams(-1, 120));

        sc.addView(r);
        setContentView(sc);
    }
}
