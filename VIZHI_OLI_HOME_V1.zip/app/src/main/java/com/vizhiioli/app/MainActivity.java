package com.vizhiioli.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

    int gold = Color.rgb(212,175,55);
    int bg = Color.rgb(8,12,22);
    int card = Color.rgb(20,27,42);
    int white = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    Button menuButton(String label, String message) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(white);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setOnClickListener(v ->
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        );
        return b;
    }

    void showHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(20, 22, 20, 10);

        TextView logo = text("விழியொலி", 36, gold, true);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 55));

        TextView tag = text("ஆடியோ • வீடியோ • கதைகள்", 19, white, false);
        root.addView(tag, new LinearLayout.LayoutParams(-1, 45));

        TextView welcome = text("உங்கள் கதைகளின் உலகத்திற்கு வரவேற்கிறோம்", 16, Color.LTGRAY, false);
        welcome.setPadding(0, 8, 0, 18);
        root.addView(welcome, new LinearLayout.LayoutParams(-1, 55));

        root.addView(section("🎧  ஆடியோ கதைகள்", "Audio Stories"));
        root.addView(section("🎬  வீடியோ", "Videos"));
        root.addView(section("📖  புதிய கதைகள்", "Stories"));

        Space space = new Space(this);
        root.addView(space, new LinearLayout.LayoutParams(1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(card);

        String[] items = {"⌂\nHome", "🎧\nAudio", "🎬\nVideo", "📖\nStories", "👤\nProfile"};
        for (String item : items) {
            Button b = new Button(this);
            b.setText(item);
            b.setTextColor(white);
            b.setTextSize(12);
            b.setAllCaps(false);
            b.setOnClickListener(v ->
                Toast.makeText(this, item.replace("\n", " ") + " — விரைவில்", Toast.LENGTH_SHORT).show()
            );
            nav.addView(b, new LinearLayout.LayoutParams(0, 70, 1));
        }
        root.addView(nav);

        setContentView(root);
    }

    View section(String title, String message) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(18, 8, 10, 8);
        box.setBackgroundColor(card);

        TextView t = text(title, 18, white, true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        box.addView(t, new LinearLayout.LayoutParams(0, 72, 1));

        Button play = new Button(this);
        play.setText("▶");
        play.setTextColor(gold);
        play.setTextSize(22);
        play.setAllCaps(false);
        play.setOnClickListener(v ->
            Toast.makeText(this, message + " — விரைவில்", Toast.LENGTH_SHORT).show()
        );
        box.addView(play, new LinearLayout.LayoutParams(70, 65));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 82);
        p.setMargins(0, 0, 0, 12);
        box.setLayoutParams(p);
        return box;
    }
}
