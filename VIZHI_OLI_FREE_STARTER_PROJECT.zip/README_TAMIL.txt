VIZHI OLI – FREE STARTER PROJECT

இது VIZHI OLI app-ன் ஆரம்ப Android project.
உள்ளே:
• Home screen
• Audio / Video / Stories sections
• Search / Favourite buttons
• Tamil + English branding

முக்கியம்:
இந்த chat environment-ல் Android build tools இல்லாததால் இங்கேயே APK compile செய்ய முடியவில்லை.
இந்த project-ஐ Android build service / Android Studio மூலம் APK ஆக build செய்யலாம்.

அடுத்த development:
1. உண்மையான logo சேர்த்தல்
2. Audio player
3. Story episodes
4. Search
5. Favourite
6. Admin/content upload
7. Login
