package com.vizhiioli.app;
import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,40,28,20); root.setBackgroundColor(Color.rgb(9,13,24));
  TextView title=new TextView(this); title.setText("விழியொலி\nVIZHI OLI"); title.setTextColor(Color.rgb(212,175,55)); title.setTextSize(28); title.setGravity(17); root.addView(title,new LinearLayout.LayoutParams(-1,150));
  TextView sub=new TextView(this); sub.setText("ஆடியோ • வீடியோ • கதைகள்"); sub.setTextColor(Color.WHITE); sub.setTextSize(17); sub.setGravity(17); root.addView(sub);
  String[] items={"🎧 ஆடியோ கதைகள்","🎬 வீடியோ","📖 கதைகள்","🔍 தேடல்","❤️ பிடித்தவை"};
  for(String s:items){Button x=new Button(this); x.setText(s); x.setTextSize(18); root.addView(x,new LinearLayout.LayoutParams(-1,70));}
  setContentView(root);
 }
}